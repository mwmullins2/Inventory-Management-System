/** Module Info
 *
 */
module mwmullinswgu.apphomescreen {
    requires javafx.controls;
    requires javafx.fxml;


    opens mwmullinswgu.apphomescreen to javafx.fxml;
    exports mwmullinswgu.apphomescreen;
}